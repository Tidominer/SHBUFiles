import pyodbc

# === Connection String ===
conn_str = (
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER=87.236.166.208;"
    f"UID=sa;"
    f"PWD=P@ssword123"
)

try:
    # === Connect to SQL Server ===
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()
    print("Connected to SQL Server successfully.")

    # === Query to get all database names ===
    cursor.execute("SELECT name FROM sys.databases;")

    # === Fetch and display results ===
    print("Available Databases:")
    for row in cursor.fetchall():
        print(f" - {row.name}")

except Exception as e:
    print(f"Error: {e}")

finally:
    # === Close connection ===
    try:
        cursor.close()
        conn.close()
    except:
        pass