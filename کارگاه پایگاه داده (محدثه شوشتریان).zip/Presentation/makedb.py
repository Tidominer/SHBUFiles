import pyodbc

# === Connection String ===
conn_str = (
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER=87.236.166.208;"
    f"UID=sa;"
    f"PWD=P@ssword123"
)

try:
    # === Connect to SQL Server ===
    conn = pyodbc.connect(conn_str, autocommit=True)
    cursor = conn.cursor()
    print("Connected to SQL Server successfully.")

    # === Create New Database ===
    create_db_query = f"CREATE DATABASE newDB3;"
    cursor.execute(create_db_query)
    print("Done!")

except Exception as e:
    print(f"Error: {e}")

finally:
    # === Close connection ===
    try:
        cursor.close()
        conn.close()
    except:
        pass